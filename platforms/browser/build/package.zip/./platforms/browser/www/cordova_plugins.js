cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/nirwan.cordova.plugin.printer/www/printer.js",
        "id": "nirwan.cordova.plugin.printer.Printer",
        "pluginId": "nirwan.cordova.plugin.printer",
        "clobbers": [
            "plugin.printer"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "nirwan.cordova.plugin.printer": "0.6.0dev"
}
// BOTTOM OF METADATA
});